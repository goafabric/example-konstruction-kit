# links
https://argo-cd.readthedocs.io/en/stable/getting_started/
https://github.com/argoproj/argo-cd/releases/latest

https://gokuldevops.medium.com/argo-cdsample-app-deployment-56b36601f279

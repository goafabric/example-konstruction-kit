return {
    name = "myheader",
    fields = {
        { config = {
            type = "record",
            fields = {
                { header_value = { type = "string", default = "roar", }, },
            },
        }, },
    }
}